//
//  LoginViewController.m
//  Day4CustomerList
//
//  Created by ozgend on 11/21/13.
//  Copyright (c) 2013 btakademi. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)btncloginClick:(id)sender {
    
    BOOL result =YES;
    
    if (result) {
        [self performSegueWithIdentifier:@"loadMasterFromLogin" sender:self];
    }
    
}
@end
